package com.ams.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
public class AssetAllocation {

		@Id
		@GeneratedValue
		private int allocationId;
		private Date allocationDate;
		private Date releaseDate;
		
		@OneToOne
		@JoinColumn(name="assetId")
		private Asset asset;
		
		@OneToOne
		@JoinColumn(name="empId")
		private Employee employee;

		public AssetAllocation() {
			// TODO Auto-generated constructor stub
		}

		public AssetAllocation(int allocationId, Date allocationDate,
				Date releaseDate, Asset asset, Employee employee) {
			super();
			this.allocationId = allocationId;
			this.allocationDate = allocationDate;
			this.releaseDate = releaseDate;
			this.asset = asset;
			this.employee = employee;
		}

		public int getAllocationId() {
			return allocationId;
		}

		public void setAllocationId(int allocationId) {
			this.allocationId = allocationId;
		}

		public Date getAllocationDate() {
			return allocationDate;
		}

		public void setAllocationDate(Date allocationDate) {
			this.allocationDate = allocationDate;
		}

		public Date getReleaseDate() {
			return releaseDate;
		}

		public void setReleaseDate(Date releaseDate) {
			this.releaseDate = releaseDate;
		}

		@Override
		public String toString() {
			return "AssetAllocation [allocationId=" + allocationId
					+ ", allocationDate=" + allocationDate + ", releaseDate="
					+ releaseDate + ", asset=" + asset + ", employee="
					+ employee + "]";
		}
}
