package com.ams.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="request")
public class Request {

	@Id
	@GeneratedValue
	@Column(name="requestId")
	private int requestId;
	@Column(name="assetName")
	private String assetName;
	@Column(name="quantity")
	private int quantity;
	@Column(name="status")
	private String status;
	@Column(name="openDate")
	private String openDate;
	@Column(name="closeDate")
	private String closeDate;
	
	public Request() {
		
	}
	
	public Request(int requestId,String assetName, int quantity, String status, 
			String openDate, String closeDate) {
		super();
		this.requestId = requestId;
		this.assetName = assetName;
		this.quantity = quantity;
		this.status = status;
		this.openDate = openDate;
		this.closeDate = closeDate;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOpenDate() {
		return openDate;
	}

	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}

	public String getCloseDate() {
		return closeDate;
	}

	public void setCloseDate(String closeDate) {
		this.closeDate = closeDate;
	}

	@Override
	public String toString() {
		return "Request [requestId=" + requestId + ", assetName=" + assetName
				+ ", quantity=" + quantity + ", status=" + status
				+ ", openDate=" + openDate + ", closeDate=" + closeDate + "]";
	}

	
	
	
}
