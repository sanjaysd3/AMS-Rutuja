package com.ams.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ams.bean.Asset;
import com.ams.bean.Request;
import com.ams.service.IAssetService;

@Controller
public class AssetController {

	@Autowired
	private IAssetService iasset;
	
	@RequestMapping("home")
	public String getHome()
	{
		return "home";
	}
	
	@RequestMapping("login")
	public String getLoginPage()
	{
		return "login";
	}
	
	@RequestMapping("managerDashboard")
	public String getManagerDashboard()
	{
		return "managerDashboard";
	}
	
	@RequestMapping("adminDashboard")
	public String getAdminDashboard()
	{
		return "adminDashboard";
	}
	
	@RequestMapping("raiseRequest")
	public String getRequestPage(Model m)
	{
		m.addAttribute("reqObj", new Request());
		return "raiseRequest";
	}
	
	@RequestMapping("addModify")
	public String getAddPage(Model m)
	{	
		m.addAttribute("assetObj", new Asset());
		return "addModify";
	}
	
	@RequestMapping(value="add", method=RequestMethod.POST)
	public String getAdd(Model m, @ModelAttribute("assetObj") Asset asset)
	{
		System.out.println(asset);
		int id=iasset.addAsset(asset);
		m.addAttribute("id", id);
		return "add";
		
	}
	
	@RequestMapping(value="request", method=RequestMethod.POST)
	public String raiseRequest(Model m, @ModelAttribute("reqObj") Request request)
	{
		//System.out.println("RAISE REQUEST!!!!");
		System.out.println(request);
		int id=iasset.raiseRequest(request);
		m.addAttribute("id", id);
		return "request";
	}
	
	@RequestMapping("update")
	public String upadte()
	{
		return "update";
	}
	
	@RequestMapping("viewStatus")
	public String viewStatusPage()
	{
		return "viewStatus";
	}
	
	@RequestMapping("viewRequest")
	public String getList(Model m)
	{
		ArrayList<Request> list=new ArrayList<>();
		list=iasset.getList();
		m.addAttribute("list", list);
		return "viewRequest";
	}
}
