package com.ams.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ams.bean.Asset;
import com.ams.bean.Request;
import com.ams.bean.UserMaster;
import com.ams.service.IAssetService;

@Controller
public class AssetController {
static int requestId, quantity;

	@Autowired
	private IAssetService iasset;
	
		/*******************home****************/
	@RequestMapping("home")
	public String getHome()
	{
		return "home";
	}
	
	@RequestMapping("getlogin")
	public String getLoginPage(Model m)
	{
		UserMaster userMaster=new UserMaster();
		m.addAttribute("loginObj",userMaster);
		return "login";
	}
	
	/**************loginModule********************/
	@RequestMapping(value="checklogin",method=RequestMethod.POST)
	public String validateLogin(Model m,@ModelAttribute("loginObj") UserMaster user)
	{
		String uname=null;
		String pass=null;
		UserMaster checkUser=null;
		String target=null;
		checkUser=iasset.login(user);
		System.out.println("returned with value");
		System.out.println(checkUser);
		if(checkUser!=null)
		{
			uname=checkUser.getUserName();
			pass=checkUser.getPassword();
			if("Manager".equalsIgnoreCase(checkUser.getUserType()) && uname.equalsIgnoreCase(user.getUserName()) && pass.equalsIgnoreCase(user.getPassword()))
			{
				target="managerDashboard";
			}
			else if("Admin".equalsIgnoreCase(checkUser.getUserType())&& uname.equalsIgnoreCase(user.getUserName()) && pass.equalsIgnoreCase(user.getPassword()))
			{
				target="adminDashboard";
			}
		}
		else{
			m.addAttribute("InvalidLogin","Login Cedentials are not valid");
			m.addAttribute("loginObj",user);
			target="login";
		}
		return target;
	
	}
	
	/***************ManagerModule****************/
	
	@RequestMapping("managerDashboard")
	public String getManagerDashboard()
	{
		return "managerDashboard";
	}
	
	@RequestMapping("raiseRequest")
	public String getRequestPage(Model m)
	{
		m.addAttribute("reqObj", new Request());
		return "raiseRequest";
	}
	
	@RequestMapping(value="request", method=RequestMethod.POST)
	public String raiseRequest(Model m, @ModelAttribute("reqObj") Request request)
	{
		//System.out.println("RAISE REQUEST!!!!");
		System.out.println(request);
		int id=iasset.raiseRequest(request);
		m.addAttribute("id", id);
		return "request";
	}
	
	@RequestMapping("viewStatus")
	public String viewStatusPage()
	{
		return "viewStatus";
	}
	
	/********************AdminModule*********************/
	@RequestMapping("adminDashboard")
	public String getAdminDashboard()
	{
		return "adminDashboard";
	}
	
	@RequestMapping("getModifyPage")
	public String getModifyPage(Model m)
	{
		ArrayList<Asset> list=new ArrayList<>();
		list=iasset.getAssetList();
		for(Asset as : list)
		{
			System.out.println("List!!!!"+as);
		}
		m.addAttribute("list", list);
		return "getModifyPage";
	}
	
	@RequestMapping("modifyAsset")
	public String modifyAsset(Model m, @RequestParam("assetId") int assetId, @ModelAttribute("assetObj") Asset asset)
	{
		asset=iasset.getAssetDetail(assetId);
		System.out.println(asset);
		m.addAttribute("asset",asset);
		return "modifyAsset";
	}
	
	@RequestMapping("update")
	public String upadte(Model m,@ModelAttribute("assetObj") Asset asset)
	{
		System.out.println(asset.getAssetId());
		System.out.println(asset);
		int status=iasset.updateAsset(asset);
		m.addAttribute("msg", "Updated Successfully ");
		return "modifyAsset";
		
	}
	
	@RequestMapping("addAsset")
	public String getAddPage(Model m)
	{	
		m.addAttribute("assetObj", new Asset());
		return "addAsset";
	}
	
	@RequestMapping(value="add", method=RequestMethod.POST)
	public String getAdd(Model m, @ModelAttribute("assetObj") Asset asset)
	{
		System.out.println(asset);
		int id=iasset.addAsset(asset);
		m.addAttribute("id", id);
		return "add";
		
	}
	
	@RequestMapping("viewRequest")
	public String getList(Model m)
	{
		ArrayList<Request> list=new ArrayList<>();
		list=iasset.getList();
		m.addAttribute("list", list);
		return "viewRequest";
	}
	
	@RequestMapping("assetSearch")
	public String getSearchList(Model m, @RequestParam("quantity") int quan, @RequestParam("requestId") int reqId)
	{
		requestId=reqId;
		quantity=quan;
		Asset asset=new Asset();
		m.addAttribute("assetObj", asset);
		int assetId=asset.getAssetId();
		if(assetId==0)
		{
			System.out.println("enter id");
		}
		else
		{
			asset=iasset.getAssetDetail(assetId);
			m.addAttribute("asset", asset);
		}
		System.out.println(asset);
		return "assetSearch";
	}
	@RequestMapping("assetSearchResult")
	public String getSearchList(Model m,@ModelAttribute("assetObj") Asset as)
	{
		
		int assetId=as.getAssetId();
		
		
			as=iasset.getAssetDetail(assetId);
			if(as!=null)
			m.addAttribute("asset", as);
			else
			m.addAttribute("msg", "No Data Found");
		
		return "assetSearch";
	}
	
	@RequestMapping("approve")
	public String approveRequest(Model m,@RequestParam("assetId") int assetId,@ModelAttribute("assetObj") Asset as)
	{
		iasset.allocateRequest(requestId, quantity, assetId);
		return null;
		
	}
	
}
