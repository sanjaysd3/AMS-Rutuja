package com.ams.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ams.bean.Asset;
import com.ams.bean.Request;
import com.ams.dao.IAssetDao;

@Service
public class AssetServiceImpl implements IAssetService {

	@Autowired
	private IAssetDao idao;
	
	@Override
	public int addAsset(Asset asset) {
		
		return idao.addAsset(asset);
	}

	@Override
	public int raiseRequest(Request request) {
		
		return idao.raiseRequest(request);
	}

	@Override
	public ArrayList<Request> getList() {
		return idao.getList();
	}

}
