package com.ams.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.ams.bean.Asset;
import com.ams.bean.Request;


@Repository
@Transactional
public class AssetDaoImpl implements IAssetDao {

	@PersistenceContext
	EntityManager entity=null;

	@Override
	public int addAsset(Asset asset) {
		
		entity.persist(asset);
		return asset.getAssetId();
	}

	@Override
	public int raiseRequest(Request request) {
		
		entity.persist(request);
		return request.getRequestId();
	}

	@Override
	public ArrayList<Request> getList() {
		Query qry=entity.createQuery("select s from Request s");
		return (ArrayList<Request>)qry.getResultList();
	}
}
